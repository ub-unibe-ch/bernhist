-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: bernhist
-- ------------------------------------------------------
-- Server version	5.7.26-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `obs_base`
--

DROP TABLE IF EXISTS `obs_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obs_base` (
  `START` smallint(6) DEFAULT NULL,
  `END` smallint(6) DEFAULT NULL,
  `STD_SYS_KEY` smallint(6) DEFAULT NULL,
  `SRC_TERM_KEY` smallint(6) DEFAULT NULL,
  `ROHDATA_SOURCE_KEY` smallint(6) DEFAULT NULL,
  `OBS_KEY` int(11) DEFAULT NULL,
  `FLAG_NOTE` smallint(6) DEFAULT NULL,
  `ROHDATA_ZEILE` smallint(6) DEFAULT NULL,
  `ROHDATA_SPALTE` smallint(6) DEFAULT NULL,
  `OBS_VALUE` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ort1`
--

DROP TABLE IF EXISTS `ort1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ort1` (
  `KEY` double DEFAULT NULL,
  `NAME` varchar(150) DEFAULT NULL,
  `TYPE` varchar(150) DEFAULT NULL,
  `level1` double DEFAULT NULL,
  `level2` varchar(150) DEFAULT NULL,
  `level3` varchar(150) DEFAULT NULL,
  `level4` varchar(150) DEFAULT NULL,
  `level5` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quellenthema`
--

DROP TABLE IF EXISTS `quellenthema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quellenthema` (
  `SRC_TERM_KEY` smallint(6) DEFAULT NULL,
  `STD_TERM_KEY` smallint(6) DEFAULT NULL,
  `STD_TERM_NAME` varchar(150) DEFAULT NULL,
  `SRC_TERM_TYPE` varchar(150) DEFAULT NULL,
  `FLAG_NOTE1` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `thema`
--

DROP TABLE IF EXISTS `thema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thema` (
  `STD_TERM_NAME` varchar(150) DEFAULT NULL,
  `STD_TERM_TYPE` varchar(150) DEFAULT NULL,
  `STD_TERM_THESA_LEVEL` smallint(6) DEFAULT NULL,
  `STD_TERM_THESA_ORD` smallint(6) DEFAULT NULL,
  `STD_TERM_FORMEL` varchar(150) DEFAULT NULL,
  `N_ELEM` smallint(6) DEFAULT NULL,
  `FLAG_NOTE` smallint(6) DEFAULT NULL,
  `STD_TERM_KEY` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `thema_in`
--

DROP TABLE IF EXISTS `thema_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thema_in` (
  `STD_TERM_KEY` smallint(6) DEFAULT NULL,
  `STD_TERM_IN` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-16 18:09:47
